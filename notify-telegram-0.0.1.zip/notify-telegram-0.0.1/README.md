# unmanic-telegram
Telegram Notification Plugin for Unmanic
